import { CanDonatePipe } from './can-donate.pipe';

describe('CanDonatePipe', () => {
  it('create an instance', () => {
    const pipe = new CanDonatePipe();
    expect(pipe).toBeTruthy();
  });
});
