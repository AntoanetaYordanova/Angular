import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class TodoService {
  // constructor(http: Http) {

  // }
  // loadTodos() {
  //   this.http.get('')
  //   console.log('load todos...');
  // }
}
