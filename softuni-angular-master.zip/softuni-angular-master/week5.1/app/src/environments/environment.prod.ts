export const environment = {
  production: true,
  apiURL: 'https://jsonplaceholder.typicode.com'
};
