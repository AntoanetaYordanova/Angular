import { ListCountPipe } from './list-count.pipe';

describe('ListCountPipe', () => {
  it('create an instance', () => {
    const pipe = new ListCountPipe();
    expect(pipe).toBeTruthy();
  });
});
